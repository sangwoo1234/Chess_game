using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chessman : MonoBehaviour
{
    public GameObject controller;
    public GameObject movePlate;

    private int xBoard = -1;
    private int yBoard = -1;

    private string player;

    public Sprite A1_rook, B1_knight, C1_bishop, D1_queen, E1_king, A2_pawn;
    public Sprite A8_rook, B8_knight, C8_bishop, D8_queen, E8_king, A7_pawn;

    public void Activate()
    {
        controller = GameObject.FindGameObjectWithTag("GameController");
        //���̶���Ŀ�� �ִ� ������Ʈ �߿��� Tag�� GameController�� ���� ã�Ƽ�
        //controller ������ �Ҵ� -> controller ������ �ش� ���� ������Ʈ�� ���� ����

        SetCoords();

        switch (this.name)
        {
            case "A1_rook": this.GetComponent<SpriteRenderer>().sprite = A1_rook; player = "white"; break;
            case "B1_knight": this.GetComponent<SpriteRenderer>().sprite = B1_knight; player = "white"; break;
            case "C1_bishop": this.GetComponent<SpriteRenderer>().sprite = C1_bishop; player = "white"; break;
            case "D1_queen": this.GetComponent<SpriteRenderer>().sprite = D1_queen; player = "white"; break;
            case "E1_king": this.GetComponent<SpriteRenderer>().sprite = E1_king; player = "white"; break;
            case "A2_pawn": this.GetComponent<SpriteRenderer>().sprite = A2_pawn; player = "white"; break;

            case "A8_rook": this.GetComponent<SpriteRenderer>().sprite = A8_rook; player = "black"; break;
            case "B8_knight": this.GetComponent<SpriteRenderer>().sprite = B8_knight; player = "black"; break;
            case "C8_bishop": this.GetComponent<SpriteRenderer>().sprite = C8_bishop; player = "black"; break;
            case "D8_queen": this.GetComponent<SpriteRenderer>().sprite = D8_queen; player = "black"; break;
            case "E8_king": this.GetComponent<SpriteRenderer>().sprite = E8_king; player = "black"; break;
            case "A7_pawn": this.GetComponent<SpriteRenderer>().sprite = A7_pawn; player = "black"; break;
        }
    }
    public void SetCoords()
    {
        
        float x = xBoard;
        float y = yBoard;

        
        x *= 1.00f;
        y *= 1.00f;

        
        x += -3.5f;
        y += -3.5f;

        
        this.transform.position = new Vector3(x, y, -1.0f);
    }

    public int GetXBoard()
    {
        return xBoard;
    }

    public int GetYBoard()
    {
        return yBoard;
    }

    public void SetXBoard(int x)
    {
        xBoard = x;
    }

    public void SetYBoard(int y)
    {
        yBoard = y;
    }

    private void OnMouseUp()
    {
        if (!controller.GetComponent<Game>().IsGameOver() && controller.GetComponent<Game>().GetCurrentPlayer() == player)
        {

            DestroyMovePlates();


            InitiateMovePlates();
        }
    }

    public void DestroyMovePlates()
    {

        GameObject[] movePlates = GameObject.FindGameObjectsWithTag("MovePlate");
        for (int i = 0; i < movePlates.Length; i++)
        {
            Destroy(movePlates[i]); 
        }
    }

    public void InitiateMovePlates()
    {
        switch (this.name)
        {
            case "D1_queen"://�Ͼ�
            case "D8_queen"://����
                LineMovePlate(1, 0);
                LineMovePlate(0, 1);
                LineMovePlate(1, 1);
                LineMovePlate(-1, 0);
                LineMovePlate(0, -1);
                LineMovePlate(-1, -1);
                LineMovePlate(-1, 1);
                LineMovePlate(1, -1);
                //�̵� ������ ���
                break;

            case "B1_knight":
            case "B8_knight":
                LMovePlate();
                break;

            case "C1_bishop":
            case "C8_bishop":
                LineMovePlate(1, 1);
                LineMovePlate(1, -1);
                LineMovePlate(-1, 1);
                LineMovePlate(-1, -1);
                break;

            case "E1_king":
            case "E8_king":
                SurroundMovePlate();
                break;

            case "A1_rook":
            case "A8_rook":
                LineMovePlate(1, 0);
                LineMovePlate(0, 1);
                LineMovePlate(-1, 0);
                LineMovePlate(0, -1);
                break;

            case "A2_pawn":
                PawnMovePlate(xBoard, yBoard + 1);
                break;

            case "A7_pawn":
                PawnMovePlate(xBoard, yBoard - 1);
                break;
        }
    }
    //���� ���� ������ ���̽� �Լ�
    public void LineMovePlate(int xIncrement, int yIncrement)
    {
        Game sc = controller.GetComponent<Game>();

        int x = xBoard + xIncrement;
        int y = yBoard + yIncrement;

        while (sc.PositionOnBoard(x, y) && sc.GetPosition(x, y) == null)
        {
            MovePlateSpawn(x, y);
            x += xIncrement;
            y += yIncrement;
        }

        if (sc.PositionOnBoard(x, y) && sc.GetPosition(x, y).GetComponent<Chessman>().player != player)
        {
            MovePlateAttackSpawn(x, y);
        }
    }
    //����Ʈ�� ŷ�� ������ ���̽� �Լ�
    public void PointMovePlate(int x, int y)
    {
        Game sc = controller.GetComponent<Game>();
        if (sc.PositionOnBoard(x, y))
        {
            GameObject cp = sc.GetPosition(x, y);

            if (cp == null)
            {
                MovePlateSpawn(x, y);
            }
            else if (cp.GetComponent<Chessman>().player != player)
            {
                MovePlateAttackSpawn(x, y);
            }
        }
    }

    public void PawnMovePlate(int x, int y)
    {
        Game sc = controller.GetComponent<Game>();
        if (sc.PositionOnBoard(x, y))
        {
            if (sc.GetPosition(x, y) == null)
            {
                MovePlateSpawn(x, y);
            }

            if (sc.PositionOnBoard(x + 1, y) && sc.GetPosition(x + 1, y) != null && sc.GetPosition(x + 1, y).GetComponent<Chessman>().player != player)
            {
                MovePlateAttackSpawn(x + 1, y);
            }

            if (sc.PositionOnBoard(x - 1, y) && sc.GetPosition(x - 1, y) != null && sc.GetPosition(x - 1, y).GetComponent<Chessman>().player != player)
            {
                MovePlateAttackSpawn(x - 1, y);
            }
        }
    }

    public void LMovePlate()
    {
        PointMovePlate(xBoard + 1, yBoard + 2);
        PointMovePlate(xBoard - 1, yBoard + 2);
        PointMovePlate(xBoard + 2, yBoard + 1);
        PointMovePlate(xBoard + 2, yBoard - 1);
        PointMovePlate(xBoard + 1, yBoard - 2);
        PointMovePlate(xBoard - 1, yBoard - 2);
        PointMovePlate(xBoard - 2, yBoard + 1);
        PointMovePlate(xBoard - 2, yBoard - 1);
    }

    public void SurroundMovePlate()
    {
        PointMovePlate(xBoard, yBoard + 1);
        PointMovePlate(xBoard, yBoard - 1);
        PointMovePlate(xBoard - 1, yBoard + 0);
        PointMovePlate(xBoard - 1, yBoard - 1);
        PointMovePlate(xBoard - 1, yBoard + 1);
        PointMovePlate(xBoard + 1, yBoard + 0);
        PointMovePlate(xBoard + 1, yBoard - 1);
        PointMovePlate(xBoard + 1, yBoard + 1);
    }
    //��� ���� ���� �����ӿ� ���� �Լ�
    public void MovePlateSpawn(int matrixX, int matrixY)
    {
  
        float x = matrixX;
        float y = matrixY;

 
        x *= 1.00f;
        y *= 1.00f;

  
        x += -3.5f;
        y += -3.5f;

        
        GameObject mp = Instantiate(movePlate, new Vector3(x, y, -3.0f), Quaternion.identity);

        MovePlate mpScript = mp.GetComponent<MovePlate>();
        mpScript.SetReference(gameObject);
        mpScript.SetCoords(matrixX, matrixY);
    }

    public void MovePlateAttackSpawn(int matrixX, int matrixY)
    {
      
        float x = matrixX;
        float y = matrixY;

      
        x *= 1.00f;
        y *= 1.00f;

       
        x += -3.5f;
        y += -3.5f;

        
        GameObject mp = Instantiate(movePlate, new Vector3(x, y, -3.0f), Quaternion.identity);

        MovePlate mpScript = mp.GetComponent<MovePlate>();
        mpScript.attack = true;
        mpScript.SetReference(gameObject);
        mpScript.SetCoords(matrixX, matrixY);
    }
}